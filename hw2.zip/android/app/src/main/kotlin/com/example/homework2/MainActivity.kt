package com.example.homework2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
